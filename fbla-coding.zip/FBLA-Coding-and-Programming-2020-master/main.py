from gui import rootScreen

rootScreen()