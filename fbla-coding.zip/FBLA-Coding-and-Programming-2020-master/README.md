# FBLA-Coding-and-Programming-2020
Coding and Programming competition for FBLA 2020. 

## Installation
To install the Program, go to [releases](https://github.com/pieromqwerty/FBLA-Coding-and-Programming-2020/releases) and download the latest relese. Extract the zip file into it's own folder and then run the program by double clicking on the "**main.exe**" file. The program is standalone so no other download is required.

## Looking at the Source Code and Modifying it
To get the source code, you can either hit the 'download zip' button or use git clone.
