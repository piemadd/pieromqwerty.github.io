from flask import Flask, render_template, send_file, redirect
from random import randint, uniform
import numpy as np
import requests
from json2html import *
import json

app = Flask('app')

@app.route('/profiles')
def profiles():
	return get_profiles()
@app.route('/hours')
def hours():
	return get_hours()

def get_profiles():
        with open('database.json') as json_file:
            data = json.load(json_file)
        yeet = data['profiles']
	ok = json2html.convert(json = yeet)
	ok = ok.replace("nameFirst", "First Name")
	ok = ok.replace("nameLast", "Last Name")
	ok = ok.replace("gradeLevel", "Grade Level")
	ok = ok.replace("hourIds", "Service Hour Sessions Worked")
	ok = ok.replace("id", "Student ID")
	return '<html><head><title>Students List</title><link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/kognise/water.css@latest/dist/dark.min.css"></head><body><center>' + ok + '</center></body></html>'

def get_hours():
        with open('database.json') as json_file:
            data = json.load(json_file)
        yeet = data['hours']
        print(yeet)
	ok = json2html.convert(json = yeet)
	print(ok)
	ok = ok.replace("date", "Date of Service Work")
	ok = ok.replace("hours", "Number of Hours Worked")
	ok = ok.replace("studentNumber", "Student ID of Volunteer")
	ok = ok.replace("hourId", "ID of Service Hour")
	return '<html><head><title>Service Hours List</title><link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/kognise/water.css@latest/dist/dark.min.css"></head><body><center>' + ok + '</center></body></html>'



app.run(host='0.0.0.0')
